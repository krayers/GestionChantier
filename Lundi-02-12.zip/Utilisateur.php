<?php

        require_once ("controleur/controleur.php");
        session_start();  // démarrage d'une session

        // on vérifie que les variables de session identifiant l'utilisateur existent
        if (isset($_SESSION['nom']) && isset($_SESSION['mdp'])) {
            $login = $_SESSION['nom'];
            $mdp = $_SESSION['mdp'];
        }

?>
<html>
  <head>
    <title> Gestion de Francilienne de Peinture </title>
    <meta charset="utf-8">
  </head>
  <body>
    <center>
      <h1> Gestion des Utilisateurs </h1>

<nav class="nav nav-pills nav-fill">
<a class="nav-link nav-item" href="Accueil.php">Acceuil</a>
<a class="nav-link nav-item" href="Devis.php">Devis</a>
<a class="nav-link nav-item" href="Société.php">Société</a>
<a class="nav-link nav-item" href="Assuré.php">Assuré</a>
<a class="nav-link nav-item" href="Metreur.php">Metreur</a>
<a class="nav-link nav-item" href="Suivi.php">Suivi</a>
<a class="nav-link nav-item" href="Dossier.php">Dossier</a>
<a class="nav-link nav-item" href="Travaux.php">Travaux</a>
<a class="nav-link nav-item" href="RDV.php">RDV</a>
<a class="nav-link nav-item" href="Facture.php">Facture</a>
</nav>


      <h3> Liste des Utilisateurs </h3>
      <?php
      $unControleur = new Controleur ("localhost","MLR1","root","");
$LesUtilisateur= $unControleur->selectAllUtilisateur();
          include ("vue/vue_selectutilisateur.php");


        include ("vue/vue_insertutilisateur.php");
          if(isset($_POST['Nouveau']))
          {

            $unControleur->insertUtilisateur($_POST);

          }
