<?php

        require_once ("controleur/controleur.php");
        session_start();  // démarrage d'une session

        // on vérifie que les variables de session identifiant l'utilisateur existent
        if (isset($_SESSION['nom']) && isset($_SESSION['mdp'])) {
            $login = $_SESSION['nom'];
            $mdp = $_SESSION['mdp'];
        }

?>
<html>
  <head>
    <title> Gestion de Francilienne de Peinture </title>
    <meta charset="utf-8">
  </head>
  <body>
    <center>
      <h1> Gestion des Suivi </h1>

<nav class="nav nav-pills nav-fill">
<a class="nav-link nav-item" href="Accueil.php">Acceuil</a>
<a class="nav-link nav-item" href="Devis.php">Devis</a>
<a class="nav-link nav-item" href="Société.php">Société</a>
<a class="nav-link nav-item" href="Assuré.php">Assuré</a>
<a class="nav-link nav-item" href="Metreur.php">Metreur</a>
<a class="nav-link nav-item" href="Suivi.php">Suivi</a>
<a class="nav-link nav-item" href="Dossier.php">Dossier</a>
<a class="nav-link nav-item" href="Travaux.php">Travaux</a>
<a class="nav-link nav-item" href="RDV.php">RDV</a>
<a class="nav-link nav-item" href="Facture.php">Facture</a>
</nav>

      <h3> Liste des Suivis </h3>
      <?php
      $unControleur = new Controleur ("localhost","MLR1","root","");
       $lesSuivre= $unControleur->selectAllSuivre();
      include ("vue/vue_select_suivre.php");


      include ("vue/vue_insert_suivre.php");
      if(isset($_POST['e']))
      {

        $unControleur->insertSuivre($_POST);

      }

      include("vue/vue_delete_suivre.php");
      if(isset($_POST['Suppr']))
      {

        $unControleur->deleteSuivre($_POST['idDO']);

      }
