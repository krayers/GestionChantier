<?php
    require_once ("modele/modele.php");
    class controleur
    {
      private $unModele;
      public function __construct($serveur, $bdd, $user, $mdp)
      {
        //instanciation de la classe modele
        $this->unModele = new Modele ($serveur, $bdd, $user, $mdp);
      }

      function selectAllDevis()
      {
        //appel de la fonction select les profs du modele
        $lesDevis= $this->unModele->selectAllDevis();

        //eventuellement faire des controles sur les donnees
        return $lesDevis;
      }
    function insertDevis($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertDevis($tab);
      }


      public function deleteDevis ($referenceD)
    {
      $this->unModele->deleteDevis($referenceD);
    }


       function selectAllPersonne()
      {
        //appel de la fonction select les profs du modele
        $lesPersonnes= $this->unModele->selectAllPersonne();

        //eventuellement faire des controles sur les donnees
        return $lesPersonnes;
      }
    function insertPersonne($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertPersonne($tab);
      }

      public function deletePersonne ($idpersonne)
    {
      $this->unModele->deletePersonne($idpersonne);
    }


        function selectAllAssure()
      {
        //appel de la fonction select les profs du modele
        $lesAssures= $this->unModele->selectAllAssure();

        //eventuellement faire des controles sur les donnees
        return $lesAssures;
      }
    function insertAssure($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertAssure($tab);
      }

      public function deleteAssure ($idpersonne)
    {
      $this->unModele->deleteAssure($idpersonne);
    }

       function selectAllSociete()
      {
        //appel de la fonction select les profs du modele
        $lesSocietes= $this->unModele->selectAllSociete();

        //eventuellement faire des controles sur les donnees
        return $lesSocietes;
      }
    function insertSociete($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertSociete($tab);
      }

public function deleteSociete ($idDO)
    {
      $this->unModele->deleteSociete($idDO);
    }
       function selectAllMetreur()
      {
        //appel de la fonction select les profs du modele
        $lesMetreurs= $this->unModele->selectAllMetreur();

        //eventuellement faire des controles sur les donnees
        return $lesMetreurs;
      }
    function insertMetreur($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertMetreur($tab);
      } 

public function deleteMetreur ($idpersonne)
    {
      $this->unModele->deleteMetreur($idpersonne);
    }
       

       function selectAllSuivre()
      {
        //appel de la fonction select les profs du modele
        $lesSuivre= $this->unModele->selectAllSuivre();

        //eventuellement faire des controles sur les donnees
        return $lesSuivre;
      }
    function insertSuivre($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertSuivre($tab);
      } 
public function deleteSuivre ($idDO)
    {
      $this->unModele->deleteSuivre($idDO);
    }
      
  
 function selectAllFacture()
      {
        //appel de la fonction select les profs du modele
        $LesFacture= $this->unModele->selectAllFacture();

        //eventuellement faire des controles sur les donnees
        return $LesFacture;
        }

       public function insertFacture($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertFacture($tab);
      }
  
 function selectAllDossier()
      {
        //appel de la fonction select les profs du modele
        $LesDossier= $this->unModele->selectAllDossier();

        //eventuellement faire des controles sur les donnees
        return $LesDossier;
      }

      public function insertDossier($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertDossier($tab);
      }

function selectAllRDV()
      {
        //appel de la fonction select les profs du modele
        $LesRDV= $this->unModele->selectAllRDV();

        //eventuellement faire des controles sur les donnees
        return $LesRDV;
      }

 public function insertRDV($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertRDV($tab);
      }

      function selectAllUtilisateur()
      {
        //appel de la fonction select les profs du modele
        $LesUtilisateur= $this->unModele->selectAllUtilisateur();

        //eventuellement faire des controles sur les donnees
        return $LesUtilisateur;
      }


     public function insertUtilisateur($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertUtilisateur($tab);
      }  


 function selectAllTravaux()
      {
        //appel de la fonction select les profs du modele
        $LesTravaux= $this->unModele->selectAllTravaux();

        //eventuellement faire des controles sur les donnees
        return $LesTravaux;
      }

      public function insertTravaux($tab)
      {
        //on peut controler les donnees avant insertion
        //le role du controleur
        $this->unModele->insertTravaux($tab);
      }

  }
  ?>
