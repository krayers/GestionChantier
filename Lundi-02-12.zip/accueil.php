<?php
    require_once ("controleur/controleur.php");
    session_start();  // démarrage d'une session

    // on vérifie que les variables de session identifiant l'utilisateur existent
    if (isset($_SESSION['nom']) && isset($_SESSION['mdp'])) {
        $login = $_SESSION['nom'];
        $mdp = $_SESSION['mdp'];
    }
    ?>

<html>
  <head>
    <title> Gestion de Francilienne de Peinture </title>
    <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<!-- BOOTSTRAP STYLES-->
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
   <!-- FONTAWESOME STYLES-->
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
      <!-- CUSTOM STYLES-->
  <link href="assets/css/custom.css" rel="stylesheet" />
   <!-- GOOGLE FONTS-->
 <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
  </head>
  <body>
      <div id="wrapper">
           <div class="navbar navbar-inverse navbar-fixed-top">
              <div class="adjust-nav">
                  <div class="navbar-header">
                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                      </button>
                      <a class="navbar-brand" href="#">
                          <img src="assets/img/lo.png" />

                      </a>

                  </div>

                  <span class="logout-spn" >
                    <a href="deconnexion.php" style="color:#fff;">Déconnexion</a>

                  </span>
              </div>
          </div>
    <center>
      <?php
      if (isset($login) && isset($mdp)) {
          echo "Bienvenue, " . $login . " ";
          echo "<h1>Accueil du site</h1>";
          ?>
            <h1> Gestion de Dossier </h1>

      <nav class="nav nav-pills nav-fill">
      <a class="nav-link nav-item" href="index.php">Acceuil</a>
      <a class="nav-link nav-item" href="Devis.php">Devis</a>
      <a class="nav-link nav-item" href="Société.php">Société</a>
      <a class="nav-link nav-item" href="Assuré.php">Assuré</a>
      <a class="nav-link nav-item" href="Metreur.php">Metreur</a>
      <a class="nav-link nav-item" href="Suivi.php">Suivi</a>
      <a class="nav-link nav-item" href="Dossier.php">Dossier</a>
      <a class="nav-link nav-item" href="Travaux.php">Travaux</a>
      <a class="nav-link nav-item" href="RDV.php">RDV</a>
      <a class="nav-link nav-item" href="Facture.php">Facture</a>
      </nav>


            <h3> Liste des Personnes </h3>
            <?php
            $unControleur = new Controleur ("localhost","MLR1","root","");

            $lesPersonnes= $unControleur->selectAllPersonne();
            include ("vue/vue_select_personne.php");


            include ("vue/vue_insert_personne.php");
            if(isset($_POST['Valider']))
            {

              $unControleur->insertPersonne($_POST);

            }

            include("vue/vue_delete_personne.php");
            if(isset($_POST['Supprimer']))
            {

              $unControleur->deletePersonne($_POST['idpersonne']);

            }
      }
      else { ?>
         <p>L'accès à cette page est réservé aux utilisateurs authentifiés</p>
         <p><a href="vue/vue_login.php">Se connecter</a></p>
      <?php } ?>

    </center>
  </body>
</html>
