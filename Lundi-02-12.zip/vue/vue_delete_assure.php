<h3> Suppression d'un assuré </h3>
    <form method="post" action="">
       ID Assure : <input type="text" name="idpersonne">
       <input type="submit" name="Su" value="Su">
    </form>
