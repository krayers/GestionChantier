<table border=1>
<tr><td> ID Travaux </td><td> ID du dossier </td><td> Date Début </td> <td> Date Fin </td></tr>
<?php
  if(isset($LesTravaux)) {
foreach ($LesTravaux as $unTravaux)
{
    echo "<tr> <td>".$unTravaux['idTra']."</td>
               <td>".$unTravaux['referenceD']."</td>
               <td>".$unTravaux['DateDeb']."</td>
               <td>".$unTravaux['DateFin']."</td>

               </tr>";
    }
  }
?>
</table>
