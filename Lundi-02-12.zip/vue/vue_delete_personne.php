<h3> Suppression d'une personne </h3>
    <form method="post" action="">
       ID Personne : <input type="text" name="idpersonne">
       <input type="submit" name="Supprimer" value="Supprimer">
    </form>
