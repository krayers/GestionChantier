<table border=1>
<tr><td> ID du RDV </td><td> ID du dossier </td><td> ID utilisateur </td> <td> Date RDV </td><td> Heure RDV </td> <td> Lieu RDV </td><td> Rapport </td></tr>
<?php
  if(isset($LesRDV)) {
foreach ($LesRDV as $unRDV)
{
    echo "<tr> <td>".$unRDV['idRDV']."</td>
               <td>".$unRDV['referenceD']."</td>
               <td>".$unRDV['idpersonne']."</td>
               <td>".$unRDV['dateRDV']."</td>
               <td>".$unRDV['heureRdv']."</td>
               <td>".$unRDV['LieuRdv']."</td>
               <td>".$unRDV['Rapport']."</td>

               </tr>";
    }
  }
?>
</table>
