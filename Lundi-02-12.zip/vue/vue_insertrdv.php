<h3> Insertion d'un RDV </h3>
	<form method ="post" action ="">
	<table border =0>

	<tr> <td> Reference du dossier  :</td>
	<td> <input type="text" name="referenceD"> </td> </tr>

	<tr> <td> Metreur  :</td>
	<td> <input type="text" name="idpersonne"> </td> </tr>

	<tr> <td> Date RDV  :</td>
	<td> <input type="date" name="dateRDV"> </td> </tr>

	<tr> <td> Heure RDV:</td>
	<td> <input type="time" name="heureRdv"> </td> </tr>

	<tr> <td> Lieu RDV :</td>
	<td> <input type="text" name="LieuRdv"> </td> </tr>

	<tr> <td> Rapport :</td>
	<td> <input type="text" name="Rapport"> </td> </tr>

	<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="Créer" value="Créer"> </td> </tr>
	</table>
	</form>
