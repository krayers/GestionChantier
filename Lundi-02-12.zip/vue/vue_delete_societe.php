<h3> Suppression d'une société </h3>
    <form method="post" action="">
       ID Société : <input type="text" name="idDO">
       <input type="submit" name="Sup" value="Sup">
    </form>
