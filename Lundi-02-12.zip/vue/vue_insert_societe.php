<h3> Insertion d'une Société </h3>
	<form method ="post" action ="">
	<table border =0>

	

	<tr> <td>  Raison Sociale :</td>
	<td> <input type="text" name="RAISON_SOCIALE"> </td> </tr>

	<tr> <td>  Adresse :</td>
	<td> <input type="text" name="ADRESSE"> </td> </tr>

	<tr> <td> Ville :</td>
	<td> <input type="text" name="VILLE"> </td> </tr>

	<tr> <td> Email :</td>
	<td> <input type="text" name="EMAIL"> </td> </tr>

	<tr> <td>  TEL:</td>
	<td> <input type="text" name="TEL"> </td> </tr>

	<tr> <td> Code Postal:</td>
	<td> <input type="text" name="CP"> </td> </tr>

	


	<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="h" value="h"> </td> </tr>
	</table>
	</form>
