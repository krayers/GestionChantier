<h3> Insertion d'un Métreur </h3>
	<form method ="post" action ="">
	<table border =0>


	<tr> <td> Compététences :</td>
	<td> <input type="text" name="competences"> </td> </tr>


	<tr> <td> Poste :</td>
	<td> <input type="text" name="poste"> </td> </tr>

	<tr> <td> Ancienneté  :</td>
	<td> <input type="text" name="anciennete"> </td> </tr>

	<tr> <td> Nom :</td>
	<td> <input type="text" name="nom"> </td> </tr>

	<tr> <td> Prenom:</td>
	<td> <input type="text" name="prenom"> </td> </tr>
	
	<tr> <td> Adresse:</td>
	<td> <input type="text" name="adresse"> </td> </tr>

	<tr> <td> Code Postale :</td>
	<td> <input type="text" name="cp"> </td> </tr>

	<tr> <td> Ville :</td>
	<td> <input type="text" name="ville"> </td> </tr>

	<tr> <td> Email :</td>
	<td> <input type="text" name="email"> </td> </tr>

	<tr> <td> Mot de Passe :</td>
	<td> <input type="text" name="mdp"> </td> </tr>

	

	<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="m" value="m"> </td> </tr>
	</table>
	</form>
