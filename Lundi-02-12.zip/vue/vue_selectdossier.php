<table border=1>
<tr><td> ID du dossier  </td><td> ID du donneur d'ordre </td><td> ID utilisateur </td> <td> ID assuré </td><td> Date début du dossier </td> <td> Montant de la franchise </td><td> Importance </td></tr>
<?php
  if(isset($LesDossier)) {
foreach ($LesDossier as $unDossier)
{
    echo "<tr> <td>".$unDossier['referenceD']."</td>
               <td>".$unDossier['idDO']."</td>
               <td>".$unDossier['idpersonne']."</td>
               <td>".$unDossier['idpersonne_1']."</td>
               <td>".$unDossier['dateDossierDeb']."</td>
               <td>".$unDossier['montantfranchise']."</td>
               <td>".$unDossier['importance']."</td>

               </tr>";
    }
  }
?>
</table>
