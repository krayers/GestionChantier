<table border=1>
<tr><td> Référence Devis  </td><td> Référence Dossier  </td><td> DateDevis  </td> <td>  Etat </td> <td> MontantHt </td><td> TVA </td><td> MontantTVA </td></tr>
<?php
  if(isset($lesDevis)) {
foreach ($lesDevis as $unDevis)
{
    echo "<tr> <td>".$unDevis['referenceD']."</td>
               <td>".$unDevis['idD']."</td>
               <td>".$unDevis['devisdate']."</td>
               <td>".$unDevis['etat']."</td>
               <td>".$unDevis['MontantHT']."</td>
               <td>".$unDevis['TVA']."</td>
               <td>".$unDevis['MontantTVA']."</td>
               </tr>";
    }
  }
?>
</table>
