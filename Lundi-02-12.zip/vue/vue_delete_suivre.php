<h3> Suppression d'une suivi</h3>
    <form method="post" action="">
       ID Suivi : <input type="text" name="idDO">
       <input type="submit" name="Suppr" value="Suppr">
    </form>
