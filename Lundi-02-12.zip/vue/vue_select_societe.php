<table border=1>
<tr><td> idSociete </td><td> Raison sociale  </td><td> Adresse  </td> <td> Ville </td> <td> Email </td> <td> TEL </td><td> CP </td> </tr>
<?php
  if(isset($lesSocietes)) {
foreach ($lesSocietes as $uneSociete)
{
    echo "<tr> <td>".$uneSociete['idDO']."</td>
               <td>".$uneSociete['RAISON_SOCIALE']."</td>
               <td>".$uneSociete['ADRESSE']."</td>
               <td>".$uneSociete['VILLE']."</td>
               <td>".$uneSociete['EMAIL']."</td>
               <td>".$uneSociete['TEL']."</td>
               <td>".$uneSociete['CP']."</td>
               </tr>";
    }
  }
?>
</table>
