<table border=1>
<tr><td> ID </td><td> Num Secu </td><td> Tel Portable </td><td> Nom </td><td> Prénom </td> <td> Adresse </td> <td> Code Postal </td><td> Ville </td><td> Email </td><td> Mot de Passe </td></tr>
<?php
  if(isset($lesAssures)) {
foreach ($lesAssures as $unAssure)
{
    echo "<tr> <td>".$unAssure['idpersonne']."</td>
              <td>".$unAssure['numsecu']."</td>
               <td>".$unAssure['tel']."</td>
               <td>".$unAssure['nom']."</td>
               <td>".$unAssure['prenom']."</td>
               <td>".$unAssure['adresse']."</td>
               <td>".$unAssure['cp']."</td>
               <td>".$unAssure['ville']."</td>
               <td>".$unAssure['email']."</td>
               <td>".$unAssure['mdp']."</td>
               
               
               </tr>";
    }
  }
?>
</table>