<h3> Suppression d'un devis</h3>
    <form method="post" action="">
       ID Devis : <input type="text" name="referenceD">
       <input type="submit" name="S" value="S">
    </form>
