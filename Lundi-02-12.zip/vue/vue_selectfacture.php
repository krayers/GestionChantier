<table border=1>
<tr><td> ID Facture </td><td> ID du dossier </td><td> Designation </td> <td> Montant TTC </td></tr>
<?php
  if(isset($LesFacture)) {
foreach ($LesFacture as $uneFacture)
{
    echo "<tr> <td>".$uneFacture['idFact']."</td>
               <td>".$uneFacture['referenceD']."</td>
               <td>".$uneFacture['Designation']."</td>
               <td>".$uneFacture['MontantTTC']."</td>

               </tr>";
    }
  }
?>
</table>
