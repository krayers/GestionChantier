<h3> Insertion d'un RDV </h3>
	<form method ="post" action ="">
	<table border =0>

	<tr> <td> ID Dossier  :</td>
	<td> <input type="text" name="referenceD"> </td> </tr>

	<tr> <td> Designation  :</td>
	<td> <input type="text" name="Designation"> </td> </tr>

	<tr> <td> Montant TTC:</td>
	<td> <input type="text" name="MontantTTC"> </td> </tr>

	<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="Facturer" value="Facturer"> </td> </tr>
	</table>
	</form>
