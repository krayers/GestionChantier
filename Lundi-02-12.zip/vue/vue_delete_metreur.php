<h3> Suppression d'un métreur </h3>
    <form method="post" action="">
       ID Metreur : <input type="text" name="idpersonne">
       <input type="submit" name="Supp" value="Supp">
    </form>
