<table border=1>
<tr><td> ID  </td><td> Compétences</td><td> Poste </td><td> Ancienneté </td><td> Nom </td><td> Prénom </td> <td> Adresse </td> <td> Code Postal </td><td> Ville </td><td> Email </td><td> Mot de Passe </td></tr>
<?php
  if(isset($lesMetreurs)) {
foreach ($lesMetreurs as $unMetreur)
{
    echo "<tr> <td>".$unMetreur['idpersonne']."</td>
              <td>".$unMetreur['competences']."</td>
               <td>".$unMetreur['poste']."</td>
               <td>".$unMetreur['anciennete']."</td>
               <td>".$unMetreur['nom']."</td>
               <td>".$unMetreur['prenom']."</td>
               <td>".$unMetreur['adresse']."</td>
               <td>".$unMetreur['cp']."</td>
               <td>".$unMetreur['ville']."</td>
               <td>".$unMetreur['email']."</td>
               <td>".$unMetreur['mdp']."</td>
               
               
               </tr>";
    }
  }
?>
</table>
