<h3> Insertion d'un Travaux </h3>
	<form method ="post" action ="">
	<table border =0>

	<tr> <td> Reference dossier  :</td>
	<td> <input type="text" name="referenceD"> </td> </tr>

	<tr> <td> Date Début :</td>
	<td> <input type="text" name="DateDeb"> </td> </tr>

	<tr> <td> Date Fin :</td>
	<td> <input type="text" name="DateFin"> </td> </tr>

	<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="Faire" value="Faire"> </td> </tr>
	</table>
	</form>
