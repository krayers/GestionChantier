<h3> Insertion d'un Suivi </h3>
	<form method ="post" action ="">
	<table border =0>

		<tr> <td> ID personne:</td>
	<td> <input type="number" name="idpersonne"> </td> </tr>

	<tr> <td> Contenu:</td>
	<td> <input type="text" name="contenu"> </td> </tr>


	<tr> <td> DateContact :</td>
	<td> <input type="date" name="dateContact"> </td> </tr>


<tr> <td> <input type="reset" name="Annuler" value="Annuler"> </td>
	<td> <input type="submit" name="e" value="e"> </td> </tr>
	</table>
	</form>