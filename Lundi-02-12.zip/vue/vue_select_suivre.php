<table border=1>
<tr><td> ID Société  </td><td> ID personnne </td><td> Contenu </td><td> DateContact </td></tr>
<?php
  if(isset($lesSuivre)) {
foreach ($lesSuivre as $unSuivre)
{
    echo "<tr>  <td>".$unSuivre['idDO']."</td>
				<td>".$unSuivre['idpersonne']."</td>
				<td>".$unSuivre['contenu']."</td>
				<td>".$unSuivre['dateContact']."</td>
               </tr>";
    }
  }
?>
</table>
